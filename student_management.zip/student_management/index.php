<?php
include "db.php";

$result = mysqli_query($conn, "SELECT * FROM students");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Management System</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<div class="container">

    <h1>Student Management System</h1>
    <p class="subtitle">CRUD Operations using PHP & MySQL</p>

    <a href="add_student.php" class="btn add-btn">+ Add Student</a>

    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Course</th>
            <th>Semester</th>
            <th>City</th>
            <th>Actions</th>
        </tr>

        <?php while ($row = mysqli_fetch_assoc($result)) { ?>

        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo htmlspecialchars($row['name']); ?></td>
            <td><?php echo htmlspecialchars($row['email']); ?></td>
            <td><?php echo htmlspecialchars($row['phone']); ?></td>
            <td><?php echo htmlspecialchars($row['course']); ?></td>
            <td><?php echo $row['semester']; ?></td>
            <td><?php echo htmlspecialchars($row['city']); ?></td>

            <td>
                <a href="edit_student.php?id=<?php echo $row['id']; ?>" 
                   class="btn edit-btn">Edit</a>

                <a href="delete_student.php?id=<?php echo $row['id']; ?>"
                   class="btn delete-btn"
                   onclick="return confirm('Are you sure you want to delete this student?');">
                   Delete
                </a>
            </td>
        </tr>

        <?php } ?>

    </table>

</div>

</body>
</html>