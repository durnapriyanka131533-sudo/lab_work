<?php
include "db.php";

$id = $_GET['id'];

$result = mysqli_query($conn, "SELECT * FROM students WHERE id=$id");
$row = mysqli_fetch_assoc($result);

if (isset($_POST['update'])) {

    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $course = $_POST['course'];
    $semester = $_POST['semester'];
    $city = $_POST['city'];

    $sql = "UPDATE students SET
            name='$name',
            email='$email',
            phone='$phone',
            course='$course',
            semester='$semester',
            city='$city'
            WHERE id=$id";

    if (mysqli_query($conn, $sql)) {
        header("Location: index.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Student</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<div class="form-container">

    <h1>Edit Student</h1>

    <form method="POST">

        <label>Student Name</label>
        <input type="text" name="name"
               value="<?php echo htmlspecialchars($row['name']); ?>"
               required>

        <label>Email</label>
        <input type="email" name="email"
               value="<?php echo htmlspecialchars($row['email']); ?>"
               required>

        <label>Phone</label>
        <input type="text" name="phone"
               value="<?php echo htmlspecialchars($row['phone']); ?>"
               required>

        <label>Course</label>
        <input type="text" name="course"
               value="<?php echo htmlspecialchars($row['course']); ?>"
               required>

        <label>Semester</label>
        <input type="number" name="semester"
               value="<?php echo $row['semester']; ?>"
               min="1" max="8" required>

        <label>City</label>
        <input type="text" name="city"
               value="<?php echo htmlspecialchars($row['city']); ?>"
               required>

        <button type="submit" name="update" class="btn edit-btn">
            Update Student
        </button>

        <a href="index.php" class="back-btn">Back</a>

    </form>

</div>

</body>
</html>