CREATE DATABASE student_db;
USE student_db;

CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    course VARCHAR(50) NOT NULL,
    semester INT NOT NULL,
    city VARCHAR(50) NOT NULL
);

INSERT INTO students (name, email, phone, course, semester, city) VALUES
('Priyanka Kumar', 'priyanka@gmail.com', '9876543210', 'BCA', 4, 'Rajkot'),
('Rahul Sharma', 'rahul@gmail.com', '9876543211', 'BCA', 3, 'Ahmedabad');
