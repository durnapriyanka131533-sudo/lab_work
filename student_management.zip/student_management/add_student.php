<?php
include "db.php";

if (isset($_POST['submit'])) {

    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $course = $_POST['course'];
    $semester = $_POST['semester'];
    $city = $_POST['city'];

    $sql = "INSERT INTO students 
            (name, email, phone, course, semester, city)
            VALUES 
            ('$name', '$email', '$phone', '$course', '$semester', '$city')";

    if (mysqli_query($conn, $sql)) {
        header("Location: index.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Student</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<div class="form-container">

    <h1>Add Student</h1>

    <form method="POST">

        <label>Student Name</label>
        <input type="text" name="name" required>

        <label>Email</label>
        <input type="email" name="email" required>

        <label>Phone</label>
        <input type="text" name="phone" required>

        <label>Course</label>
        <input type="text" name="course" required>

        <label>Semester</label>
        <input type="number" name="semester" min="1" max="8" required>

        <label>City</label>
        <input type="text" name="city" required>

        <button type="submit" name="submit" class="btn add-btn">
            Add Student
        </button>

        <a href="index.php" class="back-btn">Back</a>

    </form>

</div>

</body>
</html>